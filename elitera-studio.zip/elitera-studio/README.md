# Elitera Studio
1. Upload all files to a GitHub repo (keep .github folder).
2. Actions tab > Build APK > run. Download "Elitera-Studio-APK" artifact.
PC: just open www/index.html in Chrome/Edge.
